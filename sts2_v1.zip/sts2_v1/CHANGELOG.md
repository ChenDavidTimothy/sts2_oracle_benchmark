# 0.1.0

Initial oracle-geometry STS-2 falsification benchmark.
