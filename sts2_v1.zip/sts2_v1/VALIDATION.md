# Benchmark correctness validation

Validated on the local RTX 3060 Ti with PyTorch 2.14.0+cu130 and CuPy 14.2.0.

- `python -m pytest -q`: 7 passed, including CUDA primitive-buffer parity for EWA and triangles and a missing-hit visibility metric test.
- A0 rerun through corrected CuPy/CUDA, Torch/CUDA, and Torch/CPU. CuPy/Torch hit masks and surface IDs agree exactly for all four methods. Exact triangle PSNR is 53.47 dB on all three paths; exact EWA is 22.42 dB. EWA touches are nonzero (15,366 for exact EWA).
- A0 4x triangle quality: exact 54.84 dB, tiled 53.18 dB against the downsampled analytic reference. This reduces pixel-center sensitivity but the quality gap is still 1.66 dB.
- A2 rerun through corrected CuPy/CUDA, with Torch/CUDA backend parity checked on all four methods. Exact triangles have hit recall, hit precision, and first-hit surface agreement of 1.0. Exact EWA has hit recall 1.0, precision 0.895, and first-hit surface agreement 0.937. This is an EWA visibility/footprint limitation in the current A2 scene.
- A2 depth-only pixel traffic: 1,127 triangle touches and 28,231 EWA touches for the occluder, before mirror-mask clipping. Touches count candidate depth writes, not unique pixels.

Reproduce the runs:

```bash
.venv/bin/python -m pytest -q
.venv/bin/python -m sts2.bench --config configs/a0_smoke.yaml --device cuda --output runs/a0_corrected_cuda
.venv/bin/python -m sts2.bench --config configs/a0_smoke.yaml --device cuda --raster-backend torch --output runs/a0_corrected_torch_cuda
.venv/bin/python -m sts2.bench --config configs/a0_smoke.yaml --device cpu --raster-backend torch --output runs/a0_corrected_torch_cpu
.venv/bin/python -m sts2.bench --config configs/a2_visibility.yaml --device cuda --output runs/a2_corrected_cuda
```

Each case saves predicted/reference depth and first-hit surface ID arrays as `.npy`, images, and `metrics.csv`. CUDA A0/A2 fail if CuPy and Torch disagree on hit masks or first-hit IDs, if EWA has zero touches, or if the reflected source is black.

These timings are implementation measurements of prototype rasterizers. No optimized microtriangle or hardware-BVH baseline has been implemented, so they are not competitive performance evidence.
